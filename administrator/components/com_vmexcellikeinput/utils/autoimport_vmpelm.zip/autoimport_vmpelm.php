<?php
if(!defined('DS')) define('DS', DIRECTORY_SEPARATOR );
set_time_limit ( 60 * 10 ); //10 min
ini_set('memory_limit','256M');
///////////////////////////////////////////////////////
//CONFIG
//########################################################################################################
//Site front-end url:
$PELM_FRONT_SITE_URL = "http://your_vm_site.com/";
//Username for user to authenticate import opertaion:
$IMPORT_USERNAME = "admin";
//Password for user to authenticate import opertaion:
$IMPORT_PASSWORD = "admin";
//Languge to use for import operation
$IMPORT_LANGUAGE = "en-GB";
//CSV PIKUP METHOD:
//1. TAKE LATEST CSV FROM FOLDER OF THIS FILE
//2. PICKAP CSV FROM URL
$CSV_PICKUP_METHOD = 2;
//ONLY IF 2. PICKAP CSV FROM URL:
$CSV_URI = "http://www.somesite.com/latest_csv_export/to_import.csv";
//########################################################################################################
//########################################################################################################
//########################################################################################################
//NOTHING TO CONFIGURE AFTER THIS

$chosen_create_t = 0;
$chosen_file     = NULL; 
function generate_random_CSV_Name($length = 20) {
    return "import_".rand().".csv";
}



$csv_import_data = "";

if($CSV_PICKUP_METHOD == 1){
	$current_path = dirname(__FILE__);
	$dir = opendir($current_path); 
	while(false !== ( $file = readdir($dir)) ) { 
		if (( $file != '.' ) && ( $file != '..' ) && (!is_dir($current_path . DIRECTORY_SEPARATOR . $file))) { 
			$ext = pathinfo($file, PATHINFO_EXTENSION);
			if($ext === 'csv'){
				$ctime = filectime($current_path. DIRECTORY_SEPARATOR . $file);
				if($ctime > $chosen_create_t){
					$chosen_create_t = $ctime;
					$chosen_file     = realpath($current_path. DIRECTORY_SEPARATOR . $file);
				}
			}
		}
	}
	
	if(!$chosen_file){
		header('HTTP/1.0 500 Error');
		?>UPLOAD CSV FILE NOT FOUND!<?php
		return;
	}
	
	$csv_import_data = file_get_contents($chosen_file);
	
}else{
	$csv_import_data = file_get_contents($CSV_URI);
	$chosen_create_t = time(); 
}

if(!$csv_import_data){
	   header('HTTP/1.0 500 Error');
	   ?>COULD NOT FECH CSV UPLOAD CONTENTS!<?php
	   return;
}



///////////////////////////////////////////////////////
function configure_curl(&$ch,$cookie,$url){
	$timeout = 60 * 15;//15 min
	curl_setopt( $ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; rv:1.7.3) Gecko/20041001 Firefox/0.10.1" );
	curl_setopt( $ch, CURLOPT_URL, $url );
	curl_setopt( $ch, CURLOPT_COOKIEJAR, $cookie );
	curl_setopt( $ch, CURLOPT_COOKIEFILE,$cookie);
	curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, true );
	curl_setopt( $ch, CURLOPT_ENCODING, "" );
	curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
	curl_setopt( $ch, CURLOPT_AUTOREFERER, true );
	curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );    # required for https urls
	curl_setopt( $ch, CURLOPT_CONNECTTIMEOUT, $timeout );
	curl_setopt( $ch, CURLOPT_TIMEOUT, $timeout );
	curl_setopt( $ch, CURLOPT_MAXREDIRS, 10 );
	curl_setopt( $ch, CURLOPT_HEADER, false );
};


if(stripos($PELM_FRONT_SITE_URL,"index.php") === false){
	if($PELM_FRONT_SITE_URL[strlen($PELM_FRONT_SITE_URL) - 1] != "/")
		$PELM_FRONT_SITE_URL .= "/";
}else{
	$PELM_FRONT_SITE_URL = str_ireplace("index.php","",$PELM_FRONT_SITE_URL);
}


$content  = "";
$response = NULL;

$post_fields = array(
	   "do_import"       => 1,
	   "remote_import"   => 1,
	   "sortOrder"       => "ASC",
	   "sortColumn"      => "id", 
	   "limit"           => "1000",
	   "page"            => 1 ,
	   "vmlang"          => $IMPORT_LANGUAGE,
	   "file_timestamp"  => $chosen_create_t,
	   "csv_import_data" => $csv_import_data
);

$post_fields["auth_import"] = $IMPORT_USERNAME;
$post_fields["password"]    = $IMPORT_PASSWORD;

$cycle = 0;
do{
	$cycle++;
	
	
	$ch = curl_init();
	configure_curl($ch, "", $PELM_FRONT_SITE_URL."index.php?option=com_vmexcellikeinput" );
	
	curl_setopt($ch, CURLOPT_POST,1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields );
	
	
			
	$content     = curl_exec( $ch);
	$response    = curl_getinfo( $ch );
	$post_fields = array();
	
	if($response['http_code'] == "200"){
		if(stripos($content,'<form') !== false){
			
			$doc = new DOMDocument();
			$doc->loadHTML($content);
			$doc->normalizeDocument();
			
			$form_el = null;
			$forms = $doc->getElementsByTagName("form");
			
			foreach ($forms as $form){
				$form_el = $form;
				break;
			}
				
			if($form_el){
				
				$inputs = $form_el->getElementsByTagName("input");
				
				foreach($inputs as $input){
					if(!$input->getAttribute("name")) 
						continue;
					$post_fields[$input->getAttribute("name")] = $input->getAttribute("value");
				}
				
				$post_fields["remote_import"] = 1;
				$post_fields["do_import"]     = 1;
				
				$chosen_create_t++;
				$post_fields["file_timestamp"] = $chosen_create_t;
				
				$post_fields["auth_import"] = $IMPORT_USERNAME;
				$post_fields["password"]    = $IMPORT_PASSWORD;
				
			}else
				break;
		}
	}
	
	
}while($response['http_code'] == "200" && !empty($post_fields));



curl_close ( $ch );


		
if($response['http_code'] == "200"){
   echo $content;		
}else{
   ?>
   <h1>ERROR</h1>
   <table>
	   <?php
	   foreach($response as $key => $val){
	   ?>
	   <tr>
		   <td><?php echo $key; ?></td>
		   <td><?php echo $val; ?></td>
	   </tr>
	   <?php
	   }
	   ?>
   <table>
   <?php
   echo $content;	
}
?>